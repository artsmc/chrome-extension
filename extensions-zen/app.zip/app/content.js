/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
/*!************************!*\
  !*** ./src/content.js ***!
  \************************/

document.addEventListener('readystatechange', function(event) {
    if (document.readyState === "complete") {
        console.log('readystatechange');
        startApplication();
        const observer = new MutationObserver(function(mutationList, observer) {
            // Your handling code here
            startApplication()
        });

        // Select the element you want to watch
        const elementNode = document.getElementsByClassName("omni-conversation-pane")[0];

        // Call the observe function by passing the node you want to watch with configuration options
        observer.observe(elementNode, { 
            attributes: false, 
            childList: true, 
            subtree: false }
        );

        // When ready to diconnect
        observer.disconnect();
        function startApplication(){
          const conversation = document.getElementsByClassName("omni-conversation-pane")[0];
          const conversationStyle = {
            flexDirection: 'row'
          }
          Object.keys(conversationStyle).forEach(key => {
            conversation.style[key] = conversationStyle[key];
          });
          const conversationView = conversation.getElementsByClassName("ember-view")[0];
          const conversationViewStyle = {
            width: '80%'
          }
          Object.keys(conversationViewStyle).forEach(key => {
            conversationView.style[key] = conversationViewStyle[key];
          });
          const appSidebar = document.createElement('div');
          const appSidebarStyle = {
              border: '1px solid silver',
              width: '400px'
          }
          Object.keys(appSidebarStyle).forEach(key => {
            appSidebar.style[key] = appSidebarStyle[key];
          });
          const conversationFrame = conversation.appendChild(appSidebar);
          const iframe = document.createElement('iframe');
          const styles = {
            height: "100%",
            backgroundColor: "#fff",
            border: "none",
            width: "41%",
            position: "absolute",
            top: "0px",
            bottom: "0px",
            padding: "20px",
            display: "flex",
            transition: "width 0.5s ease-in-out",
            boxShadow: "0px 10px 60px -30px rgba(0, 0, 0, 0.3)"
          };
          Object.keys(styles).forEach(key => {
            iframe.style[key] = styles[key];
          });
          const hashConverter = window.location.hash.replace("#", "#/");
          iframe.src = chrome.runtime.getURL("index.html" + hashConverter);
          const docFrame = appSidebar.appendChild(iframe);
        }
        
    }
});


/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udGVudC5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxXQUFXO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFdBQVc7QUFDWDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQUFDO0FBQ0QiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9JbmJveFNESy8uL3NyYy9jb250ZW50LmpzIl0sInNvdXJjZXNDb250ZW50IjpbIlxyXG5kb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdyZWFkeXN0YXRlY2hhbmdlJywgZnVuY3Rpb24oZXZlbnQpIHtcclxuICAgIGlmIChkb2N1bWVudC5yZWFkeVN0YXRlID09PSBcImNvbXBsZXRlXCIpIHtcclxuICAgICAgICBjb25zb2xlLmxvZygncmVhZHlzdGF0ZWNoYW5nZScpO1xyXG4gICAgICAgIHN0YXJ0QXBwbGljYXRpb24oKTtcclxuICAgICAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBNdXRhdGlvbk9ic2VydmVyKGZ1bmN0aW9uKG11dGF0aW9uTGlzdCwgb2JzZXJ2ZXIpIHtcclxuICAgICAgICAgICAgLy8gWW91ciBoYW5kbGluZyBjb2RlIGhlcmVcclxuICAgICAgICAgICAgc3RhcnRBcHBsaWNhdGlvbigpXHJcbiAgICAgICAgfSk7XHJcblxyXG4gICAgICAgIC8vIFNlbGVjdCB0aGUgZWxlbWVudCB5b3Ugd2FudCB0byB3YXRjaFxyXG4gICAgICAgIGNvbnN0IGVsZW1lbnROb2RlID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcIm9tbmktY29udmVyc2F0aW9uLXBhbmVcIilbMF07XHJcblxyXG4gICAgICAgIC8vIENhbGwgdGhlIG9ic2VydmUgZnVuY3Rpb24gYnkgcGFzc2luZyB0aGUgbm9kZSB5b3Ugd2FudCB0byB3YXRjaCB3aXRoIGNvbmZpZ3VyYXRpb24gb3B0aW9uc1xyXG4gICAgICAgIG9ic2VydmVyLm9ic2VydmUoZWxlbWVudE5vZGUsIHsgXHJcbiAgICAgICAgICAgIGF0dHJpYnV0ZXM6IGZhbHNlLCBcclxuICAgICAgICAgICAgY2hpbGRMaXN0OiB0cnVlLCBcclxuICAgICAgICAgICAgc3VidHJlZTogZmFsc2UgfVxyXG4gICAgICAgICk7XHJcblxyXG4gICAgICAgIC8vIFdoZW4gcmVhZHkgdG8gZGljb25uZWN0XHJcbiAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xyXG4gICAgICAgIGZ1bmN0aW9uIHN0YXJ0QXBwbGljYXRpb24oKXtcclxuICAgICAgICAgIGNvbnN0IGNvbnZlcnNhdGlvbiA9IGRvY3VtZW50LmdldEVsZW1lbnRzQnlDbGFzc05hbWUoXCJvbW5pLWNvbnZlcnNhdGlvbi1wYW5lXCIpWzBdO1xyXG4gICAgICAgICAgY29uc3QgY29udmVyc2F0aW9uU3R5bGUgPSB7XHJcbiAgICAgICAgICAgIGZsZXhEaXJlY3Rpb246ICdyb3cnXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBPYmplY3Qua2V5cyhjb252ZXJzYXRpb25TdHlsZSkuZm9yRWFjaChrZXkgPT4ge1xyXG4gICAgICAgICAgICBjb252ZXJzYXRpb24uc3R5bGVba2V5XSA9IGNvbnZlcnNhdGlvblN0eWxlW2tleV07XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICAgIGNvbnN0IGNvbnZlcnNhdGlvblZpZXcgPSBjb252ZXJzYXRpb24uZ2V0RWxlbWVudHNCeUNsYXNzTmFtZShcImVtYmVyLXZpZXdcIilbMF07XHJcbiAgICAgICAgICBjb25zdCBjb252ZXJzYXRpb25WaWV3U3R5bGUgPSB7XHJcbiAgICAgICAgICAgIHdpZHRoOiAnODAlJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgT2JqZWN0LmtleXMoY29udmVyc2F0aW9uVmlld1N0eWxlKS5mb3JFYWNoKGtleSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnZlcnNhdGlvblZpZXcuc3R5bGVba2V5XSA9IGNvbnZlcnNhdGlvblZpZXdTdHlsZVtrZXldO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBjb25zdCBhcHBTaWRlYmFyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XHJcbiAgICAgICAgICBjb25zdCBhcHBTaWRlYmFyU3R5bGUgPSB7XHJcbiAgICAgICAgICAgICAgYm9yZGVyOiAnMXB4IHNvbGlkIHNpbHZlcicsXHJcbiAgICAgICAgICAgICAgd2lkdGg6ICc0MDBweCdcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIE9iamVjdC5rZXlzKGFwcFNpZGViYXJTdHlsZSkuZm9yRWFjaChrZXkgPT4ge1xyXG4gICAgICAgICAgICBhcHBTaWRlYmFyLnN0eWxlW2tleV0gPSBhcHBTaWRlYmFyU3R5bGVba2V5XTtcclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgY29uc3QgY29udmVyc2F0aW9uRnJhbWUgPSBjb252ZXJzYXRpb24uYXBwZW5kQ2hpbGQoYXBwU2lkZWJhcik7XHJcbiAgICAgICAgICBjb25zdCBpZnJhbWUgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpZnJhbWUnKTtcclxuICAgICAgICAgIGNvbnN0IHN0eWxlcyA9IHtcclxuICAgICAgICAgICAgaGVpZ2h0OiBcIjEwMCVcIixcclxuICAgICAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcIiNmZmZcIixcclxuICAgICAgICAgICAgYm9yZGVyOiBcIm5vbmVcIixcclxuICAgICAgICAgICAgd2lkdGg6IFwiNDElXCIsXHJcbiAgICAgICAgICAgIHBvc2l0aW9uOiBcImFic29sdXRlXCIsXHJcbiAgICAgICAgICAgIHRvcDogXCIwcHhcIixcclxuICAgICAgICAgICAgYm90dG9tOiBcIjBweFwiLFxyXG4gICAgICAgICAgICBwYWRkaW5nOiBcIjIwcHhcIixcclxuICAgICAgICAgICAgZGlzcGxheTogXCJmbGV4XCIsXHJcbiAgICAgICAgICAgIHRyYW5zaXRpb246IFwid2lkdGggMC41cyBlYXNlLWluLW91dFwiLFxyXG4gICAgICAgICAgICBib3hTaGFkb3c6IFwiMHB4IDEwcHggNjBweCAtMzBweCByZ2JhKDAsIDAsIDAsIDAuMylcIlxyXG4gICAgICAgICAgfTtcclxuICAgICAgICAgIE9iamVjdC5rZXlzKHN0eWxlcykuZm9yRWFjaChrZXkgPT4ge1xyXG4gICAgICAgICAgICBpZnJhbWUuc3R5bGVba2V5XSA9IHN0eWxlc1trZXldO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgICBjb25zdCBoYXNoQ29udmVydGVyID0gd2luZG93LmxvY2F0aW9uLmhhc2gucmVwbGFjZShcIiNcIiwgXCIjL1wiKTtcclxuICAgICAgICAgIGlmcmFtZS5zcmMgPSBjaHJvbWUucnVudGltZS5nZXRVUkwoXCJpbmRleC5odG1sXCIgKyBoYXNoQ29udmVydGVyKTtcclxuICAgICAgICAgIGNvbnN0IGRvY0ZyYW1lID0gYXBwU2lkZWJhci5hcHBlbmRDaGlsZChpZnJhbWUpO1xyXG4gICAgICAgIH1cclxuICAgICAgICBcclxuICAgIH1cclxufSk7XHJcblxyXG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=